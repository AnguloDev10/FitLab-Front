import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sideclient',
  templateUrl: './sideclient.component.html',
  styleUrls: ['./sideclient.component.css']
})
export class SideclientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
