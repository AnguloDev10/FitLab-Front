import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sideadmin',
  templateUrl: './sideadmin.component.html',
  styleUrls: ['./sideadmin.component.css']
})
export class SideadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
