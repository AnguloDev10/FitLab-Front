export interface IUser {
    userName: string,
    password: string
}