import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidenutri',
  templateUrl: './sidenutri.component.html',
  styleUrls: ['./sidenutri.component.css']
})
export class SidenutriComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
