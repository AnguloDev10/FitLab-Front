import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-perfil',
  templateUrl: './admin-perfil.component.html',
  styleUrls: ['./admin-perfil.component.css']
})
export class AdminPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
