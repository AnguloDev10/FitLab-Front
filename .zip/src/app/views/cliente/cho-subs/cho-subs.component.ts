import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cho-subs',
  templateUrl: './cho-subs.component.html',
  styleUrls: ['./cho-subs.component.css']
})
export class ChoSubsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
