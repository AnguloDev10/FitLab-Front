import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nutri-list',
  templateUrl: './nutri-list.component.html',
  styleUrls: ['./nutri-list.component.css']
})
export class NutriListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
