import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-progress',
  templateUrl: './user-progress.component.html',
  styleUrls: ['./user-progress.component.css']
})
export class UserProgressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}